# basic-banking-system
# BASIC-BANKING-SYSTEM
The Sparks Foundation Internship Project : Basic Banking System

## Features

- A Dynamic Website is used to transfer money between users.

- The Database contains two tables- Users Table & Transaction Table

- The User table have basic fields such as name, email & current balance.

- The Transaction table records all transfers happened along with their time.

The Flow of the Website:

Home Page > View all Users > Select and View one User > Transfer Money > Select reciever > View all Users > View Transfer History.


## Tech Stack

**Front-end:** HTML, CSS, BOOTSTRAP, JAVASCRIPT

**Back-end:** PHP

**Database:** MySQL






